package com.cloudinary.test;

/***
 * Marker interface for Junit categories.
 */
public interface TimeoutTest {
}
