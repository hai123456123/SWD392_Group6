package com.cloudinary.test.helpers;

public final class Feature {
    private Feature() {}

    public static final String ALL = "all";
    public static final String DYNAMIC_FOLDERS = "dynamic_folders";
    public static final String BACKEDUP_ASSETS = "backedup_assets";
    public static final String CONDITIONAL_METADATA_RULES = "conditional_metadata_rules";
}
