package com.cloudinary.test;

public class AccountApiTest extends AbstractAccountApiTest {
}
