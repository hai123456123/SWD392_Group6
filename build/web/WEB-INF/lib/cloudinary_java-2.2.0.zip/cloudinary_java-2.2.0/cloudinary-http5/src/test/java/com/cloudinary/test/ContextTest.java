package com.cloudinary.test;

public class ContextTest extends AbstractContextTest {

}