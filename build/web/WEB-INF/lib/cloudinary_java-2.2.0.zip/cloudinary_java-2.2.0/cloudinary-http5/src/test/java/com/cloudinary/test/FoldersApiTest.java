package com.cloudinary.test;

public class FoldersApiTest extends AbstractFoldersApiTest {
}
