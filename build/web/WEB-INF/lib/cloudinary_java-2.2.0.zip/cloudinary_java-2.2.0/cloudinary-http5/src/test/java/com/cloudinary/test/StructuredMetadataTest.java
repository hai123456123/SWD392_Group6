package com.cloudinary.test;

public class StructuredMetadataTest extends AbstractStructuredMetadataTest {
}