package com.cloudinary.transformation;

public class SubtitlesLayer extends TextLayer {
    public SubtitlesLayer() {
        this.resourceType = "subtitles";
    }
}
